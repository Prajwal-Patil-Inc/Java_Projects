package com.newproject.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.newproject.bean.Meds;
import com.newproject.dao.MedsDAO;

/**
 * Servlet implementation class MedsServlet
 */
@WebServlet("/MedsServlet")
public class MedsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int amount, mid, pid;
	String PIDS;
	Meds m1 = new Meds();
	MedsDAO dao = new MedsDAO();
	public MedsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String medNameGet = request.getParameter("MedNameInp");
		String quantity = request.getParameter("MedQuant");
		int inpQuant = Integer.parseInt(quantity);
		m1.setQuantity(inpQuant);

		ArrayList<String> datas = new ArrayList<String>();
		datas = dao.displayMedsIssued(medNameGet, inpQuant);
		HttpSession ob = request.getSession();
		
		request.setAttribute("Medsids", datas.get(0));
		String mid = datas.get(0);
		int miid = Integer.parseInt(mid);
		m1.setMid(miid);
		request.setAttribute("mnames", datas.get(1));
		request.setAttribute("mquant", datas.get(2));
		request.setAttribute("mrate", datas.get(3));
		request.setAttribute("mamount", datas.get(4));
		request.getRequestDispatcher("issueDisplay.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession ob = request.getSession();
		String one = (String) ob.getAttribute("value");
		System.out.println("SuccessInMeds" + one);
		int ones = Integer.parseInt(one);
		System.out.println("Success in conversion" + ones);
		m1.setPid(ones);
		Meds med1 = new Meds();
		ArrayList<Meds> datass;
	
		//MedicinesIssued
		dao.IssueMedsToPatient(m1);
	
		//ShowIssuedMedicinesToPatient
		datass = dao.MedsIssuedToPatients(m1);
		request.setAttribute("MedsList", datass);
		request.getRequestDispatcher("addMedicines.jsp").forward(request, response);
	}
}
