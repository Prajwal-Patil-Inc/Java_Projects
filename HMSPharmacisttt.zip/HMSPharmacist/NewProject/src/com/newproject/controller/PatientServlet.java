package com.newproject.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.newproject.bean.Meds;
import com.newproject.dao.MedsDAO;

@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int on;
	String id;
	int ids;
	Meds m1 = new Meds();
	MedsDAO dao = new MedsDAO();
	public PatientServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		id = request.getParameter("id");
		int i = Integer.parseInt(id);
		m1.setPid(ids);
		System.out.println(ids);
		on = m1.getPid();
		
		ArrayList<String> datas = new ArrayList<String>();
		datas = dao.displayData(i);
		
		HttpSession ob = request.getSession();
		ob.setAttribute("value", id);
		
		request.setAttribute("ids", datas.get(0));
		request.setAttribute("names", datas.get(1));
		request.setAttribute("ages", datas.get(2));
		request.setAttribute("adrs", datas.get(3));
		request.setAttribute("doas", datas.get(4));
		request.setAttribute("mednames", datas.get(5));
		request.setAttribute("quants", datas.get(6));
		request.setAttribute("rates", datas.get(7));
		request.setAttribute("amounts", datas.get(8));
		request.getRequestDispatcher("displayPatient.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
}
