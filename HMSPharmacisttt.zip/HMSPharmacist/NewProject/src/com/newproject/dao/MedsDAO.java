package com.newproject.dao;

import java.awt.print.Book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.newproject.bean.Meds;

public class MedsDAO {
	int amount, amount2;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
	private String dburl="jdbc:mysql://localhost:3306/test2";
	private String dbuname = "root";
	private String dbpassword = "prajwal@1";
	private String dbdriver = "com.mysql.cj.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dburl, dbuname, dbpassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	//Display Patient Data
	public ArrayList<String> displayData(int id) {
		ArrayList<String> data = new ArrayList<String>();
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "select * from test2.patient where id="+id+"";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				data.add(String.valueOf(rs.getInt("id")));
				data.add(rs.getString("name"));
				data.add(String.valueOf(rs.getInt("age")));
				data.add(rs.getString("address"));
				String strDate = dateFormat.format(rs.getDate("doa"));
				data.add(strDate);
				data.add(rs.getString("medname"));
				data.add(String.valueOf(rs.getInt("quantissued")));
				data.add(String.valueOf(rs.getInt("rate")));
				amount = rs.getInt(7) * rs.getInt(8);
				String sql1 = "update test2.patient set amount=" + amount + " where id=" + id + "";
				try {
					PreparedStatement ps = con.prepareStatement(sql1);
					ps.executeUpdate();
				} catch (Exception e) {
					System.out.println(e);
				}
				data.add(String.valueOf(amount));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return data;
	}
	
	//IssueMedicine
	public ArrayList<String> displayMedsIssued(String medname, int quant){
		ArrayList<String> data2 = new ArrayList<String>();
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "select * from test2.med where medName like '%" + medname+ "' and quantity!=0 and quantity>" + quant + "";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				data2.add(String.valueOf(rs.getInt("id")));
				data2.add(rs.getString("medName"));
				data2.add(String.valueOf(quant));
				String sql2 = "update test2.med set quantity = quantity - " + quant + "";
				try {
					PreparedStatement ps = con.prepareStatement(sql2);
					ps.executeUpdate();
				} catch (Exception e) {
					System.out.println(e);
				}
				data2.add(String.valueOf(rs.getInt("rate")));
				amount2 = rs.getInt("rate") * quant;
				data2.add(String.valueOf(amount2));
			}
			}
		catch(Exception e) {
			e.printStackTrace();
		}
		return data2;
	}
	
	//MedicinesIssuedToPatients
	public void IssueMedsToPatient(Meds meds){
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into test2.patientmed values(?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, meds.getPid());
			ps.setInt(2, meds.getMid());
			ps.setInt(3, meds.getQuantity());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Meds> MedsIssuedToPatients(Meds meds){
		ArrayList<Meds> data3 = new ArrayList<Meds>();
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "select * from test2.patientmed where PID=" + meds.getPid() + "";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				Meds m1 = new Meds();
				m1.setPid(rs.getInt("PID"));
				m1.setMid(rs.getInt("MID"));
				m1.setQuantity(rs.getInt("quant"));
				data3.add(m1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return data3;
	}
}
