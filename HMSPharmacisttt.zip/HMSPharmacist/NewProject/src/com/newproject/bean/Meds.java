package com.newproject.bean;

public class Meds {
int pid, mid, quantity, rate, amount;
String medName;
public Meds() {
	super();
}
public Meds(int pid, int mid, int quantity, int rate, int amount, String medName) {
	super();
	this.pid = pid;
	this.mid = mid;
	this.quantity = quantity;
	this.rate = rate;
	this.amount = amount;
	this.medName = medName;
}

public Meds(int pid, int mid, int quantity) {
	super();
	this.pid = pid;
	this.mid = mid;
	this.quantity = quantity;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public int getMid() {
	return mid;
}
public void setMid(int mid) {
	this.mid = mid;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public String getMedName() {
	return medName;
}
public void setMedName(String medName) {
	this.medName = medName;
}

}
