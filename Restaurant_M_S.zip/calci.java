
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.*;
import javax.swing.JTabbedPane;

public class calci {

	public JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	double firstnum;
	double secondnum;
	double result;
	String operations;
	String answer;

	double US_A = 1.52;
	double Canada_Dollar = 2.03;
	double Brazil_real = 5.86;
	double Indian_rupee = 100.68;
	double Phillippine_peso = 71.74;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calci w = new calci();
					w.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calci() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(0, 0, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 23));
		textField_5.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_5.setBounds(15, 16, 305, 74);
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel.setBounds(26, 123, 463, 267);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblChickenBurger = new JLabel("Chicken Burger");
		lblChickenBurger.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblChickenBurger.setBounds(23, 22, 232, 32);
		panel.add(lblChickenBurger);
		
		JLabel label = new JLabel("Chicken Burger Meal ");
		label.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label.setBounds(23, 65, 232, 32);
		panel.add(label);
		
		JLabel label_1 = new JLabel("Cheese Burger");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_1.setBounds(23, 108, 232, 32);
		panel.add(label_1);
		
		/* JLabel label_2 = new JLabel("Chicken Burger");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_2.setBounds(23, 155, 232, 32);
		panel.add(label_2);
		*/
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setBounds(264, 32, 177, 22);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_1.setColumns(10);
		textField_1.setBounds(264, 77, 177, 22);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_2.setColumns(10);
		textField_2.setBounds(264, 120, 177, 22);
		panel.add(textField_2);
		
		JLabel lblDrink = new JLabel("Drink");
		lblDrink.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDrink.setBounds(23, 151, 153, 22);
		panel.add(lblDrink);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select a Drink", "Apple Juice", "Coca Cola", "Mango Juice", "Pepsi", "Mazaa", "Sprite", "Mountain Dew", "Slice"}));
		comboBox.setBounds(23, 184, 153, 20);
		panel.add(comboBox);
		
		JLabel lblNewLabel_2 = new JLabel("Qty");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(264, 153, 102, 20);
		panel.add(lblNewLabel_2);
		
		textField_3 = new JTextField();
		textField_3.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_3.setBounds(264, 184, 177, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		final JCheckBox chckbxNewCheckBox = new JCheckBox("Home Delivery");
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.BOLD, 15));
		chckbxNewCheckBox.setBounds(23, 218, 153, 23);
		panel.add(chckbxNewCheckBox);
		
		final JCheckBox chckbxTax = new JCheckBox("Tax");
		chckbxTax.setFont(new Font("Tahoma", Font.BOLD, 15));
		chckbxTax.setBounds(264, 220, 177, 23);
		panel.add(chckbxTax);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(23, 150, 418, 6);
		panel.add(separator);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_1.setBounds(499, 123, 354, 267);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Choose one", "USA", "Canada", "Brazil", "India", "Phillippines"}));
		comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		comboBox_1.setBounds(97, 71, 153, 20);
		panel_1.add(comboBox_1);
		
		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 24));
		textField_4.setColumns(10);
		textField_4.setBounds(97, 121, 154, 22);
		panel_1.add(textField_4);
		
		final JLabel label_7 = new JLabel("");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_7.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_7.setBounds(97, 166, 154, 29);
		panel_1.add(label_7);
		
		JButton btnNewButton = new JButton("Convert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			double USA_Dollar = Double.parseDouble(textField_4.getText());
			if(comboBox_1.getSelectedItem().equals("USA")) {
				String cConvert1 = String.format("$ %.2f",USA_Dollar * US_A);
				label_7.setText(cConvert1);
			}
			
			if(comboBox_1.getSelectedItem().equals("Canada")) {
				String cConvert2 = String.format("$ %.2f",USA_Dollar * Canada_Dollar);
				label_7.setText(cConvert2);
			}
			
			if(comboBox_1.getSelectedItem().equals("Brazil")) {
				String cConvert3 = String.format("$ %.2f",USA_Dollar* Brazil_real);
				label_7.setText(cConvert3);
			}
			
			if(comboBox_1.getSelectedItem().equals("India")) {
				String cConvert4 = String.format("Rs %.2f",USA_Dollar* Indian_rupee);
				label_7.setText(cConvert4);
			}

			
			
			
			
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(54, 221, 89, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Close");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				label_7.setText(null);
				textField_4.setText(null);
				comboBox_1.setSelectedItem("Choose one");
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(209, 221, 89, 23);
		panel_1.add(btnNewButton_1);
		
		JLabel lblCurrencyConverter = new JLabel("Currency Converter");
		lblCurrencyConverter.setHorizontalAlignment(SwingConstants.CENTER);
		lblCurrencyConverter.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCurrencyConverter.setBounds(54, 25, 244, 35);
		panel_1.add(lblCurrencyConverter);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_2.setBounds(26, 401, 463, 163);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label_2 = new JLabel("Cost of Drink");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_2.setBounds(21, 23, 232, 32);
		panel_2.add(label_2);
		
		JLabel label_3 = new JLabel("Cost of Meal ");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_3.setBounds(21, 66, 232, 32);
		panel_2.add(label_3);
		
		JLabel label_4 = new JLabel("Cost of Delivery");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_4.setBounds(21, 109, 232, 32);
		panel_2.add(label_4);
		
		final JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(263, 23, 178, 29);
		lblNewLabel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_2.add(lblNewLabel_1);
		
		final JLabel label_5 = new JLabel("");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_5.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_5.setBounds(263, 66, 178, 29);
		panel_2.add(label_5);
		
		final JLabel label_6 = new JLabel("");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_6.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_6.setBounds(263, 109, 178, 29);
		panel_2.add(label_6);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_3.setBounds(499, 401, 354, 163);
		frame.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblTax = new JLabel("Tax");
		lblTax.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblTax.setBounds(21, 22, 46, 32);
		panel_3.add(lblTax);
		
		JLabel lblSubTotal = new JLabel("Sub total");
		lblSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblSubTotal.setBounds(21, 65, 129, 32);
		panel_3.add(lblSubTotal);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblTotal.setBounds(21, 109, 62, 32);
		panel_3.add(lblTotal);
		
		final JLabel label_10 = new JLabel("");
		label_10.setHorizontalAlignment(SwingConstants.RIGHT);
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_10.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_10.setBounds(166, 112, 163, 29);
		panel_3.add(label_10);
		
		final JLabel label_11 = new JLabel("");
		label_11.setHorizontalAlignment(SwingConstants.RIGHT);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_11.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_11.setBounds(166, 68, 163, 29);
		panel_3.add(label_11);
		
		final JLabel label_12 = new JLabel("");
		label_12.setHorizontalAlignment(SwingConstants.RIGHT);
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_12.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_12.setBounds(166, 25, 163, 29);
		panel_3.add(label_12);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_4.setBounds(863, 123, 290, 441);
		frame.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(20, 23, 248, 395);
		panel_4.add(tabbedPane);
		
		JPanel panel_6 = new JPanel();
		tabbedPane.addTab("Receipt", null, panel_6, null);
		panel_6.setLayout(null);
		
		final JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(10, 25, 223, 28);
		panel_6.add(lblNewLabel_3);
		
		final JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(10, 75, 223, 28);
		panel_6.add(lblNewLabel_4);
		
		final JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 123, 223, 30);
		panel_6.add(lblNewLabel_5);
		
		final JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(10, 178, 223, 28);
		panel_6.add(lblNewLabel_6);
		
		final JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_7.setBounds(10, 328, 223, 28);
		panel_6.add(lblNewLabel_7);
		
		final JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(10, 289, 223, 28);
		panel_6.add(lblNewLabel_8);
		
		final JLabel lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_9.setBounds(10, 242, 223, 28);
		panel_6.add(lblNewLabel_9);
		
		JPanel panel_7 = new JPanel();
		tabbedPane.addTab("Calculator", null, panel_7, null);
		panel_7.setLayout(null);
		
		textField_5 = new JTextField();
		textField_5.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_5.setColumns(10);
		textField_5.setBounds(1, 21, 242, 53);
		panel_7.add(textField_5);
		
		final JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String NewButton=null;
				
				if(textField_5.getText().length()>0) {
					StringBuilder strB =  new StringBuilder(textField_5.getText());
					strB.deleteCharAt(textField_5.getText().length()-1);
					NewButton = strB.toString();
					textField_5.setText(NewButton);
					
				}
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 10));
		button.setBounds(1, 105, 46, 43);
		panel_7.add(button);
		
		JButton button_1 = new JButton("C");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				textField_5.setText(null);
			}
		});
		button_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_1.setBounds(62, 105, 46, 43);
		panel_7.add(button_1);
		
		final JButton button_2 = new JButton("%");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double firstnum = Double.parseDouble(textField_5.getText());
				textField_5.setText("");
				String operations = "%";
			}
		});
		button_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		button_2.setBounds(131, 105, 46, 43);
		panel_7.add(button_2);
		
		JButton button_3 = new JButton("+");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				firstnum = Double.parseDouble(textField_5.getText());
				textField_5.setText("");
				operations="+";
			}
		});
		button_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_3.setBounds(197, 105, 46, 43);
		panel_7.add(button_3);
		
		JButton button_4 = new JButton("-");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				firstnum = Double.parseDouble(textField_5.getText());
				textField_5.setText("");
				operations="-";
			}
		});
		button_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_4.setBounds(197, 147, 46, 43);
		panel_7.add(button_4);
		
		final JButton button_5 = new JButton("9");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String EnterNumber = textField_5.getText() + button_5.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_5.setBounds(131, 147, 46, 43);
		panel_7.add(button_5);
		
		final JButton button_6 = new JButton("8");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String EnterNumber =textField_5.getText() + button_6.getText();
				textField_5.setText(EnterNumber);
				
			}
		});
		button_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_6.setBounds(62, 147, 46, 43);
		panel_7.add(button_6);
		
		final JButton button_7 = new JButton("7");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField_5.getText() + button_7.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_7.setBounds(1, 147, 46, 43);
		panel_7.add(button_7);
		
		final JButton button_8 = new JButton("4");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String EnterNumber = textField_5.getText() + button_8.getText();
				textField_5.setText(EnterNumber);
				
			}
		});
		button_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_8.setBounds(1, 189, 46, 43);
		panel_7.add(button_8);
		
		final JButton button_9 = new JButton("5");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField_5.getText() + button_9.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_9.setBounds(62, 189, 46, 43);
		panel_7.add(button_9);
		
		final JButton button_10 = new JButton("6");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber =textField_5.getText() + button_10.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_10.setBounds(131, 189, 46, 43);
		panel_7.add(button_10);
		
		JButton button_11 = new JButton("*");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				firstnum = Double.parseDouble(textField_5.getText());
				textField_5.setText("");
				operations="*";
			}
		});
		button_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_11.setBounds(197, 189, 46, 43);
		panel_7.add(button_11);
		
		JButton button_12 = new JButton("/");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				firstnum = Double.parseDouble(textField_5.getText());
				textField_5.setText("");
				operations="/";
			}
		});
		button_12.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_12.setBounds(197, 231, 46, 43);
		panel_7.add(button_12);
		
		final JButton button_13 = new JButton("3");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String EnterNumber = textField_5.getText() + button_13.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_13.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_13.setBounds(131, 231, 46, 43);
		panel_7.add(button_13);
		
		final JButton button_14 = new JButton("2");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField_5.getText() + button_14.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_14.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_14.setBounds(62, 231, 46, 43);
		panel_7.add(button_14);
		
		final JButton button_15 = new JButton("1");
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField_5.getText() + button_15.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_15.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_15.setBounds(1, 231, 46, 43);
		panel_7.add(button_15);
		
		JButton button_16 = new JButton("0");
		button_16.setFont(new Font("Tahoma", Font.BOLD, 20));
		button_16.setBounds(-18, 384, 65, 58);
		panel_7.add(button_16);
		
		JButton button_17 = new JButton(".");
		button_17.setFont(new Font("Tahoma", Font.BOLD, 20));
		button_17.setBounds(62, 384, 65, 58);
		panel_7.add(button_17);
		
		JButton button_18 = new JButton("\u00B1");
		button_18.setFont(new Font("Tahoma", Font.BOLD, 20));
		button_18.setBounds(142, 384, 65, 58);
		panel_7.add(button_18);
		
		JButton button_19 = new JButton("=");
		button_19.setFont(new Font("Tahoma", Font.BOLD, 20));
		button_19.setBounds(222, 384, 65, 58);
		panel_7.add(button_19);
		
		final JButton button_20 = new JButton("0");
		button_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String EnterNumber = textField_5.getText() + button_20.getText();
				textField_5.setText(EnterNumber);
			}
		});
		button_20.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_20.setBounds(1, 274, 46, 43);
		panel_7.add(button_20);
		
		final JButton button_21 = new JButton(".");
		button_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (arg0.getSource()==button_21) {
					textField_5.setText(textField_5.getText().concat("."));
					}	
			}
		});
		button_21.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_21.setBounds(62, 274, 46, 43);
		panel_7.add(button_21);
		
		JButton button_22 = new JButton("\u00B1");
		button_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 double ops =Double.parseDouble(String.valueOf(textField_5.getText()));
					ops = ops *(-1);
					textField_5.setText(String.valueOf(ops));
			}
		});
		button_22.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_22.setBounds(131, 274, 46, 43);
		panel_7.add(button_22);
		
		JButton button_23 = new JButton("=");
		button_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String answer;
				secondnum = Double.parseDouble(textField_5.getText());
				if(operations=="+"){
					result = firstnum + secondnum;
					answer = String.format("%.2f",result);
					textField_5.setText(answer);
				}
				else if (operations == "-")
				{
					result = firstnum - secondnum;
					answer = String.format("%.2f",result);
					textField_5.setText(answer);
						
				}
				else if (operations == "*")
				{
					result = firstnum * secondnum;
					answer = String.format("%.2f",result);
					textField_5.setText(answer);
						
				}
				else if (operations == "/")
				{
					result = firstnum / secondnum;
					answer = String.format("%.2f",result);
					textField_5.setText(answer);
						
				}
				else if (operations == "%")
				{
					result = firstnum % secondnum;
					answer = String.format("%.2f",result);
					textField_5.setText(answer);
						
				}

			}
		});
		button_23.setFont(new Font("Tahoma", Font.BOLD, 12));
		button_23.setBounds(197, 274, 46, 43);
		panel_7.add(button_23);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_5.setBounds(26, 569, 1127, 70);
		frame.getContentPane().add(panel_5);
		panel_5.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_2.setBounds(788, 25, 89, 23);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
		});
		panel_5.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Reset");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblNewLabel_1.setText(null);
				label_5.setText(null);
				label_6.setText(null);
				label_12.setText(null);
				label_11.setText(null);
				label_10.setText(null);
				label_7.setText(null);
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				comboBox.setSelectedItem("Select a Drink");
				comboBox_1.setSelectedItem("Choose one");
				chckbxTax.setSelected(false);
				chckbxNewCheckBox.setSelected(false);
				lblNewLabel_3.setText(null);				
				lblNewLabel_4.setText(null);
				lblNewLabel_5.setText(null); 
				lblNewLabel_6.setText(null); 
				lblNewLabel_7.setText( null);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_3.setBounds(590, 25, 89, 23);
		panel_5.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Receipt");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				double Qty1 = Double.parseDouble(textField.getText());
				double Qty2 = Double.parseDouble(textField_1.getText());
				double Qty3 = Double.parseDouble(textField_2.getText());
				lblNewLabel_3.setText("Restaurant Management System");				
				lblNewLabel_4.setText("Chicken Burger:\t" +Qty1);
				lblNewLabel_5.setText("Chicken Burger Meal:" +Qty2); 
				lblNewLabel_6.setText("and Cheese Burger: "+Qty3); 
				
				lblNewLabel_7.setText( "Have a Nice day! Thank You! ");
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_4.setBounds(390, 25, 89, 23);
		panel_5.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Total");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double ChicBurger = Double.parseDouble(textField.getText());
				double iChicBurger = 2.09;
				double Burger;
				Burger = (ChicBurger * iChicBurger);
				String pMeal = String.format("%.2f", Burger);
				label_5.setText(pMeal);
				
				double ChicBurgerMeal = Double.parseDouble(textField_1.getText());
				double iChicBurgerMeal = 4.59;
				double BurgerMeal;
				BurgerMeal = (ChicBurgerMeal * iChicBurgerMeal);
				String cbMeal = String.format("%.2f",BurgerMeal + Burger);
				label_5.setText(cbMeal);
				
				double CheeseBurger = Double.parseDouble(textField_2.getText());
				double CheeseBurgerPrice = 3.49;
				double CheeseBurgerMeal;
				CheeseBurgerMeal = (CheeseBurger * CheeseBurgerPrice);
				String cheese = String.format("%.2f",CheeseBurgerMeal + BurgerMeal + Burger);
				label_5.setText(cheese);
				
				double iDelivery = 3.39;
				if(chckbxNewCheckBox.isSelected()) {
					String pDelivery = String.format("%.2f", iDelivery);
					label_6.setText(pDelivery);
				}
				else {
					label_6.setText("0");
				}
				
				//===================================Drinks================================================//
				double Drinks = Double.parseDouble(textField_3.getText());
				double AppleJuice = 1.20 * Drinks;
				double CocaCola = 2.00* Drinks;
				double MangoJuice = 3.00 * Drinks;
				double Pepsi = 1.50 * Drinks;
				double Mazaa = 1.00 * Drinks;
				double Sprite = 0.50 * Drinks;
				double MountainDew = 2.10 * Drinks;
				double Slice = 1.70 * Drinks;
				
				if (comboBox.getSelectedItem().equals("Apple Juice")) {
					String cApple_Juice = String.format("%.2f", AppleJuice);
					 lblNewLabel_1.setText(cApple_Juice);
				}
				if (comboBox.getSelectedItem().equals("Coca Cola")) {
					String cCoca_Cola = String.format("%.2f", CocaCola);
					lblNewLabel_1.setText(cCoca_Cola);
				}
				if(comboBox.getSelectedItem().equals("Mango Juice")) {
					String cMango_Juice = String.format("%.2f",MangoJuice);
					lblNewLabel_1.setText(cMango_Juice);
				}
				if(comboBox.getSelectedItem().equals("Pepsi")) {
					String cPepsi = String.format("%.2f",Pepsi);
					lblNewLabel_1.setText(cPepsi);
				}
				if(comboBox.getSelectedItem().equals("Mazaa")) {
					String cMazaa = String.format("%.2f",Mazaa);
					lblNewLabel_1.setText(cMazaa);
				}
				if(comboBox.getSelectedItem().equals("Sprite")) {
					String cSprite = String.format("%.2f",Sprite);
					lblNewLabel_1.setText(cSprite);
				}
				if(comboBox.getSelectedItem().equals("Mountain Dew")) {
					String cMountainDew = String.format("%.2f",MountainDew);
					lblNewLabel_1.setText(cMountainDew);
				}
				if(comboBox.getSelectedItem().equals("Slice")) {
					String cSlice = String.format("%.2f",Slice);
					lblNewLabel_1.setText(cSlice);
				}
				//==========================================Tax==================================================//
					
				Double cTotal1 = Double.parseDouble(lblNewLabel_1.getText());
				Double cTotal2 = Double.parseDouble(label_5.getText());
				Double cTotal3 = Double.parseDouble(label_6.getText());
				Double AllTotal = (cTotal1 + cTotal2 + cTotal3)/100;
				if(chckbxTax.isSelected()){
					String iTotal = String.format("%.2f", AllTotal);
					
					label_12.setText(iTotal);
				}
				
				
				//=======================================Total=================================================//
				double cTotal4 = Double.parseDouble(label_12.getText());
				
				double subTotal = (cTotal1 + cTotal2 + cTotal3);
				String isubTotal = String.format("$ %.2f", subTotal);
				label_11.setText(isubTotal);
				
				double allTotal = (cTotal1 + cTotal2 + cTotal3 + cTotal4);
				String iallTotal = String.format("$ %.2f", allTotal);
				label_10.setText(iallTotal);
				
				String iTaxTotal = String.format("$ %.2f",cTotal4);
				label_12.setText(iTaxTotal);
				
				
			
				
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_5.setBounds(184, 25, 89, 23);
		panel_5.add(btnNewButton_5);
		
		JLabel lblNewLabel = new JLabel("Restaurant Management System");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
		lblNewLabel.setBounds(118, 42, 997, 51);
		frame.getContentPane().add(lblNewLabel);
	
		JLabel lblNewLabel_10 = new JLabel("New label");
		lblNewLabel_10.setBounds(0, 0, 1194, 691);
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\Sai\\workspace2\\Hello\\src\\Daydream 1920x1200.jpg"));
		frame.getContentPane().add(lblNewLabel_10);
	}
	
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}


		
		
	


