import java.awt.EventQueue;

import javax.swing.JFrame;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import java.awt.Color;
import java.awt.Panel;

public class Rest2 {

	private JFrame frame;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField textField;
	private JButton btnExit;
	private JLabel lblNewLabel_3;
	private Panel panel;
	private JPanel panel_1;
	private JPanel panel_3;
	private JPanel panel_2;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rest2 window = new Rest2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Rest2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setName("HElli\r\ncopete\r\nsdas\r\nfdfd");
		frame.setBounds(0, 0, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Log In");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (textField.getText().equals("prajwalpatil") && passwordField.getText().equals("crashvendetta")) {
				calci w = new calci();
				try {
					
				
				w.frame.setVisible(true);
				
				
				}
			catch(Exception e){
				
			}
			}
			}
		});
		
		btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		
		lblNewLabel_3 = new JLabel("Login Page ");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(183, 43, 733, 63);
		frame.getContentPane().add(lblNewLabel_3);
		btnExit.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnExit.setBounds(623, 513, 106, 33);
		frame.getContentPane().add(btnExit);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBounds(475, 513, 100, 33);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(null);
				passwordField.setText(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(315, 513, 106, 33);
		frame.getContentPane().add(btnNewButton);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(10, 435, 789, -423);
		frame.getContentPane().add(layeredPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLUE);
		panel.setBounds(218, 273, 145, 48);
		panel.setBorder(new LineBorder(Color.BLACK, 8));
		frame.getContentPane().add(panel);
		
		lblNewLabel_1 = new JLabel("User ID");
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.GREEN);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_1.setBackground(Color.BLUE);
		panel_1.setBounds(218, 364, 145, 48);
		frame.getContentPane().add(panel_1);
		
		lblNewLabel_2 = new JLabel("Password");
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(Color.GREEN);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_3.setBounds(595, 273, 244, 58);
		frame.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField.setBounds(10, 11, 224, 36);
		panel_3.add(textField);
		textField.setColumns(10);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_2.setBounds(595, 364, 244, 58);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10, 11, 224, 36);
		panel_2.add(passwordField);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Sai\\workspace2\\Hello\\src\\i_love_you_he_loves_you-1280x1024.jpg"));
		lblNewLabel.setBounds(-81, 0, 1265, 692);
		frame.getContentPane().add(lblNewLabel);
		
		
		
		
	}
}
